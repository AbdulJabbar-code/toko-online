<?php
require "session.php";
require "../koneksi.php";

$query = mysqli_query($con, "SELECT a.*, b.nama AS nama_kategori FROM produk a JOIN kategori b ON a.kategori_id=b.id");
$jumlahProduk = mysqli_num_rows($query);

$queryKategori = mysqli_query($con, "SELECT * FROM kategori");

// Fungsi untuk menghasilkan file Excel
function exportToExcel($data){
    $filename = 'data_produk.csv';

    // Buat file Excel
    $file = fopen($filename, 'w');

    // Set header kolom
    $header = ['No.', 'Nama', 'Kategori', 'Harga', 'Ketersediaan Stok'];
    fputcsv($file, $header);

    // Set data produk
    $no = 1;
    while($rowdata = mysqli_fetch_array($data)){
        $rowData = [$no, $rowdata['nama'], $rowdata['nama_kategori'], $rowdata['harga'], $rowdata['ketersediaan_stok']];
        fputcsv($file, $rowData);
        $no++;
    }

    fclose($file);

    // Mengirim file Excel ke browser
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="'.$filename.'"');
    header('Cache-Control: max-age=0');
    readfile($filename);
    exit();
}

// Pengecekan apakah tombol export Excel ditekan
if(isset($_POST['export_excel'])){
    exportToExcel($query);
}
function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[random_int(0, $charactersLength - 1)];
    }
    return $randomString;
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Produk</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../fontawesome-free-6.4.0-web/css/brands.min.css">
</head>

<style>
    .no-decoration{
        text-decoration: none;
    }
    form div{
        margin-bottom: 10px;
    }
</style>

<body>
    <?php require "navbar.php";  ?>
    <div class="container mt-5">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item active" aria-current="page">
                    <a href="../adminpanel" class="no-decoration text-muted"><i class="fas fa-home"></i>Home</a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">
                 Produk
                </li>
            </ol>
        </nav>

        <div class="my-5 col-12 col-md-6" >
            <h2>Tambah Produk</h2>

            <form action="" method="post" enctype="multipart/form-data">
            <div>
                <label for="nama">Nama</label>
                <input type="text" id="nama" name="nama" class="form-control" autocomplete="off" required>
            </div>
            <div>
                <label for="kategori">Kategori</label>
                <select name="kategori" id="kategori" class="form-control" required>
                    <option value="">Pilih Salah Satu</option>
                    <?php
                    while($data=mysqli_fetch_array($queryKategori)){
                        ?>
                        <option value="<?php echo $data['id']; ?>"><?php echo $data['nama'];?></option>
                        <?php
                    }
                     ?>
                </select>
            </div>
            <div>
                <label for="harga">Harga</label>
                <input type="number" class="form-control" name="harga" required>
            </div>
            <div>
                <label for="foto">Foto</label>
                <input type="file" name="foto" id="foto" class="form-control"> 
            </div>
            <div>
                <label for="detail">Detail</label>
                <textarea name="detail" id="detail" cols="30" rows="10" class="form-control"></textarea>
            </div>
            <div>
                <label for="ketersediaan_stok">Ketersediaan Stok</label>
                <select name="ketersediaan_stok" id="ketersediaan_stok" class="form-control">
                    <option value="tersedia">Tersedia</option>
                    <option value="habis">habis</option>
                </select>
            </div>
            <div>
                <button type="submit" class="btn btn-primary" name="simpan">Simpan</button>
            </div>
            </form>
            <?php
            if(isset($_POST['simpan'])){
                $nama = htmlspecialchars($_POST['nama']);
                $kategori = htmlspecialchars($_POST['kategori']);
                $harga = htmlspecialchars($_POST['harga']);                
                $detail = htmlspecialchars($_POST['detail']);                
                $ketersediaan_stok = htmlspecialchars($_POST['ketersediaan_stok']);                

                $target_dir = "../image/";
                $nama_file = basename($_FILES["foto"]["name"]);
                $target_file = $target_dir . $nama_file;
                $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
                $image_size = $_FILES["foto"]['size'];
                $random_name = generateRandomString(20);
                $new_name = $random_name . "." . $imageFileType;


                if($nama=='' || $kategori=='' || $harga==''){
                    ?>
                    <div class="alert alert-warning mt-3" role="alert">
                    Nama,Kategori,dan Harga wajib di isi
                    </div>
                    <?php
                }
                else{
                    if($nama_file!=''){
                        if($image_size > 500000){
                            ?>
                            <div class="alert alert-warning mt-3" role="alert">
                            File tidak Boleh lebih dari 500 KB
                            </div>
                            <?php
                        }
                        else{
                           if($imageFileType != 'jpg' && $imageFileType != 'png' && $imageFileType 
                           != 'gif'){
                            ?>
                            <div class="alert alert-warning mt-3" role="alert">
                            file wajib bertipe jpg/png/gif
                            </div>
                            <?php
                           }
                           else{
                            move_uploaded_file($_FILES["foto"]['tmp_name'], 
                            $target_dir . $new_name);
                           }
                        }
                    }
                    //query insert to produk table
                    $queryTambah = mysqli_query($con, "INSERT INTO produk (kategori_id, nama, harga, foto, 
                    detail, ketersediaan_stok) VALUES ('$kategori', '$nama', '$harga', '$new_name',
                     '$detail', '$ketersediaan_stok')");

                    if($queryTambah){
                        ?>
                        <div class="alert alert-primary mt-3" role="alert">
                        Produk Berhasil Tersimpan
                        </div>
                        <meta http-equiv="refresh" content="2; url=produk.php" />
    
                        <?php
                    }
                    else{
                        echo mysqli_error($con);
                    }
                }
            }
            ?>
        </div>

        <div class="mt-3 md-5"></div>
        <h2>List Produk</h2>
        <form action="" method="GET" class="mb-3">
            <div class="input-group">
                <input type="text" class="form-control" name="search" placeholder="Cari produk...">
                <div class="input-group-append">
                    <button class="btn btn-outline-secondary" type="submit" name="submit"><i class="fas fa-search"></i></button>
                </div>
            </div>
        </form>


        <div class="table-responsive mt-5"></div>
            <table class="table" >
                    <thead>
                        <tr>
                            <th>NO.</th>
                            <th>Nama</th>
                            <th>Kategori</th>
                            <th>Harga</th>
                            <th>Ketersediaan Stok</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            // Cek apakah form pencarian telah disubmit
                            if(isset($_GET['submit'])){
                                $search = mysqli_real_escape_string($con, $_GET['search']);
                                // Buat query pencarian
                                $query = mysqli_query($con, "SELECT a.*, b.nama AS nama_kategori FROM produk a JOIN kategori b ON a.kategori_id=b.id WHERE a.nama LIKE '%$search%'");
                                $jumlahProduk = mysqli_num_rows($query);
                                // Ekspor ke Excel jika tombol export Excel ditekan
                                if(isset($_POST['export_excel'])){
                                    exportToExcel($query);
                                }
                            }

                            if($jumlahProduk == 0){
                                ?>
                                <tr>
                                    <td colspan="6" class="text-center">Data Produk Tidak Tersedia</td>
                                </tr>
                                <?php
                            }
                            else{
                                $jumlah = 1;
                                while($data = mysqli_fetch_array($query)){
                                    ?>
                                    <tr>
                                        <td><?php echo $jumlah; ?></td>
                                        <td><?php echo $data['nama']; ?></td>
                                        <td><?php echo $data['nama_kategori']; ?></td>
                                        <td><?php echo $data['harga']; ?></td>
                                        <td><?php echo $data['ketersediaan_stok']; ?></td>
                                        <td>
                                            <a href="produk-detail.php?p=<?php echo $data['id']; ?>" class="btn btn-info"><i class="fas fa-search"></i></a>
                                        </td>
                                    </tr>
                                    <?php
                                    $jumlah++;
                                }
                            }
                        ?>
                    </tbody>
            </table>
            <div>
            <form method="post" action="">
                <button class="btn btn-success" type="submit" name="export_excel"><i class="fas fa-download"></i> Export to Excel</button>
            </form>

            </div>
        </div>   
    </div>

    <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../fontawesome-free-6.4.0-web/js/all.min.js"></script>
</body>
</html>