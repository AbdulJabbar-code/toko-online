<?php
require "session.php";
require "../koneksi.php";

$id = $_GET['p'];

$query = mysqli_query($con, "SELECT * FROM pembelian_pulsa WHERE id='$id'");
$data = mysqli_fetch_array($query);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Pembelian Pulsa</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
</head>
<body>
    <?php require "navbar.php"; ?>
    <div class="container mt-5">
        <h2>Detail Pembelian Pulsa</h2>
        <div class="col-12 col-md-6">
            <form action="" method="post">
                <div>
                    <label for="nama_pelanggan">Nama Pelanggan</label>
                    <input type="text" name="nama_pelanggan" id="nama_pelanggan" class="form-control" value="<?php echo $data['nama_pelanggan']; ?>">
                </div>
                <div class="mt-3">
                    <label for="nomor_telepon">Nomor Telepon</label>
                    <input type="text" name="nomor_telepon" id="nomor_telepon" class="form-control" value="<?php echo $data['nomor_telepon']; ?>">
                </div>
                <div class="mt-3">
                    <label for="provider">Provider</label>
                    <input type="text" name="provider" id="provider" class="form-control" value="<?php echo $data['provider']; ?>">
                </div>
                <div class="mt-3">
                    <label for="nilai_pulsa">Nilai Pulsa</label>
                    <input type="text" name="nilai_pulsa" id="nilai_pulsa" class="form-control" value="<?php echo $data['nilai_pulsa']; ?>">
                </div>
                <div class="mt-5 d-flex justify-content-between">
                    <button type="submit" class="btn btn-primary" name="editBtn">Edit</button>
                    <button type="submit" class="btn btn-danger" name="deleteBtn">Hapus</button>
                </div>
            </form>

            <?php 
            if(isset($_POST['editBtn'])){
                $nama_pelanggan = htmlspecialchars($_POST['nama_pelanggan']);
                $nomor_telepon = htmlspecialchars($_POST['nomor_telepon']);
                $provider = htmlspecialchars($_POST['provider']);
                $nilai_pulsa = htmlspecialchars($_POST['nilai_pulsa']);

                $queryUpdate = mysqli_query($con, "UPDATE pembelian_pulsa SET 
                    nama_pelanggan='$nama_pelanggan', nomor_telepon='$nomor_telepon',
                    provider='$provider', nilai_pulsa='$nilai_pulsa' WHERE id='$id'");

                if($queryUpdate){
                    ?>
                    <div class="alert alert-primary mt-3" role="alert">
                        Pembelian Pulsa Berhasil Diupdate
                    </div>
                    <meta http-equiv="refresh" content="2; url=pulsa.php" />
                    <?php
                } else {
                    echo mysqli_error($con);
                }
            }

            if(isset($_POST['deleteBtn'])){
                $queryDelete = mysqli_query($con, "DELETE FROM pembelian_pulsa WHERE id='$id'");
                if($queryDelete){
                    ?>
                    <div class="alert alert-primary mt-3" role="alert">
                        Pembelian Pulsa Berhasil Dihapus
                    </div>
                    <meta http-equiv="refresh" content="0; url=pulsa.php" />
                    <?php
                } else {
                    echo mysqli_error($con);
                }
            }
            ?>
        </div>
    </div>

    <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>
