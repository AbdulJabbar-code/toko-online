<?php
require "session.php";
require "../koneksi.php";

// Pengecekan apakah tombol export Excel ditekan
if(isset($_POST['export_excel'])){
    $queryPulsa = mysqli_query($con, "SELECT * FROM pembelian_pulsa");
    exportToExcel($queryPulsa);
    exit();
}
$queryPulsa = mysqli_query($con, "SELECT * FROM pembelian_pulsa");
$jumlahPulsa = mysqli_num_rows($queryPulsa);

// Pengecekan apakah tombol submit pencarian ditekan
if(isset($_POST['submit'])){
    $search = $_POST['search'];

    // Query untuk mencari data pembelian pulsa berdasarkan nama pelanggan
    $queryPulsa = mysqli_query($con, "SELECT * FROM pembelian_pulsa WHERE nama_pelanggan LIKE '%$search%'");

    // Menghitung jumlah data hasil pencarian
    $jumlahPulsa = mysqli_num_rows($queryPulsa);
}


// Fungsi untuk menghasilkan file Excel
function exportToExcel($data){
    $filename = 'data_pembelian_pulsa.csv';

    // Buat file Excel
    $file = fopen($filename, 'w');

    // Set header kolom
    $header = ['No.', 'Nama Pelanggan', 'Nomor Telepon', 'Provider', 'Nilai Pulsa'];
    fputcsv($file, $header);

    // Set data pembelian pulsa
    $no = 1;
    while($rowdata = mysqli_fetch_array($data)){
        $rowData = [
            $no,
            $rowdata['nama_pelanggan'],
            $rowdata['nomor_telepon'],
            $rowdata['provider'],
            $rowdata['nilai_pulsa']
        ];
        fputcsv($file, $rowData);
        $no++;
    }

    fclose($file);

    // Mengirim file Excel ke browser
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="'.$filename.'"');
    header('Cache-Control: max-age=0');
    readfile($filename);
    exit();
}

// Pengecekan apakah tombol simpan ditekan
if(isset($_POST['simpan'])){
    $nama_pelanggan = $_POST['nama_pelanggan'];
    $nomor_telepon = $_POST['nomor_telepon'];
    $provider = $_POST['provider'];
    $nilai_pulsa = $_POST['nilai_pulsa'];

    // Query untuk menyimpan data pembelian pulsa baru
    $querySimpan = mysqli_query($con, "INSERT INTO pembelian_pulsa (nama_pelanggan, nomor_telepon, provider, nilai_pulsa) 
                VALUES ('$nama_pelanggan', '$nomor_telepon', '$provider', '$nilai_pulsa')");

    if($querySimpan){
        header('Location: pulsa.php');
        exit();
    } else {
        echo "Error: " . mysqli_error($con);
    }
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pembelian Pulsa</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../fontawesome-free-6.4.0-web/css/brands.min.css">
</head>
<style>
    .no-decoration{
        text-decoration: none;
    }
    .table-custom {
        width: 100%;
        border-collapse: collapse;
    }

    .table-custom th,
    .table-custom td {
        padding: 8px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }

    .table-custom th {
        background-color: #f2f2f2;
        font-weight: bold;
    }

    .table-custom tr:nth-child(even) {
        background-color: #f9f9f9;
    }

    .table-custom tr:hover {
        background-color: #f5f5f5;
    }
    
</style>
<body>
    <?php require "navbar.php";  ?>
    <div class="container mt-5">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item active" aria-current="page">
                    <a href="../adminpanel" class="no-decoration text-muted"><i class="fas fa-home"></i>Home</a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">
                 Pembelian Pulsa
                </li>
            </ol>
        </nav>

        <div class="mt-5">
            <h2>Tambah Pembelian Pulsa</h2>
            <form action="" method="POST">
                <div class="form-group">
                    <label for="nama_pelanggan">Nama Pelanggan</label>
                    <input type="text" class="form-control" id="nama_pelanggan" name="nama_pelanggan" required>
                </div>
                <div class="form-group">
                    <label for="nomor_telepon">Nomor Telepon</label>
                    <input type="text" class="form-control" id="nomor_telepon" name="nomor_telepon" required>
                </div>
                <div class="form-group">
                    <label for="provider">Provider</label>
                    <input type="text" class="form-control" id="provider" name="provider" required>
                </div>
                <div class="form-group">
                    <label for="nilai_pulsa">Nilai Pulsa</label>
                    <input type="text" class="form-control" id="nilai_pulsa" name="nilai_pulsa" required>
                </div>
                <button type="submit" class="btn btn-primary" name="simpan">Simpan</button>
            </form>
        </div>

        <div class="mt-3">
            <h2>Daftar Pembelian Pulsa</h2>

            <div class="input-group mt-3 mb-3">
                <input type="text" id="search-input" class="form-control" placeholder="Cari nama pelanggan...">
                <div class="input-group-append">
                    <button class="btn btn-primary" id="search-btn" type="button"><i class="fas fa-search"></i> Cari</button>
                </div>
            </div>

            <div class="table-responsive mt-5">
                <table class="table table-custom">
                    <thead>
                        <tr>
                            <th>NO.</th>
                            <th>Nama Pelanggan</th>
                            <th>Nomor Telepon</th>
                            <th>Provider</th>
                            <th>Nilai Pulsa</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 1;
                        while($rowdata = mysqli_fetch_array($queryPulsa)){
                            ?>
                            <tr>
                                <td><?php echo $no; ?></td>
                                <td><?php echo $rowdata['nama_pelanggan']; ?></td>
                                <td><?php echo $rowdata['nomor_telepon']; ?></td>
                                <td><?php echo $rowdata['provider']; ?></td>
                                <td><?php echo $rowdata['nilai_pulsa']; ?></td>
                                <td>
                                    <a href="pulsa-detail.php?p=<?php echo $rowdata['id']; ?>" class="btn btn-info"><i class="fas fa-search"></i></a>
                                </td>
                            </tr>
                            <?php
                            $no++;
                        }
                        ?>
                    </tbody>
                </table>
                <div>
                    <form method="post" action="">
                        <button class="btn btn-success" type="submit" name="export_excel"><i class="fas fa-download"></i> Export to Excel</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../fontawesome-free-6.4.0-web/js/all.min.js"></script>
    <script>
        // Fungsi untuk mengatur event klik pada tombol pencarian
        document.getElementById('search-btn').addEventListener('click', function() {
            // Mendapatkan nilai input pencarian
            var searchValue = document.getElementById('search-input').value.toLowerCase();
            
            // Mendapatkan semua baris data dalam tabel
            var rows = document.querySelectorAll('.table-custom tbody tr');

            // Melakukan iterasi untuk setiap baris data
            for (var i = 0; i < rows.length; i++) {
                var rowData = rows[i].getElementsByTagName('td');
                var found = false;

                // Melakukan pencocokan dengan nilai input pencarian pada kolom NPelanggan
                if (rowData[1].innerText.toLowerCase().indexOf(searchValue) > -1) {
                    found = true;
                }

                // Menampilkan atau menyembunyikan baris data berdasarkan hasil pencocokan
                if (found) {
                    rows[i].style.display = '';
                } else {
                    rows[i].style.display = 'none';
                }
            }
        });
    </script>
</body>
</html>
