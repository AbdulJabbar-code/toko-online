<?php
session_start();
require ('../koneksi.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .main {
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .login-box {
            width: 350px;
            border: 1px solid #ccc;
            padding: 20px;
            border-radius: 5px;
            background-color: #f9f9f9;
        }
    </style>
</head>
<body>
    <div class="main">
        <div class="login-box">
            <h2 class="text-center mb-4">Login</h2>
            <form action="" method="post">
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" class="form-control" name="username" id="username" required>
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" class="form-control" name="password" id="password" required>
                </div>
                <div class="text-center">
                    <button class="btn btn-success form-control mt-3" type="submit" name="loginbtn">LOGIN</button>
                </div>
                <div>
                <?php
                if(isset($_POST['loginbtn'])){
                    $username = $_POST['username'];
                    $password = $_POST['password'];

                    $query = mysqli_query($con, "SELECT * FROM users WHERE username='$username'");
                    $countdata = mysqli_num_rows($query);
                    $data = mysqli_fetch_array($query);

                    if($countdata > 0){
                        if ($password === $data['password']) {
                            $_SESSION['username'] = $data['username'];
                            $_SESSION['login'] = true;
                            header('location: index.php');
                        } else {
                            echo '<div class="alert alert-danger mt-4" role="alert">Password Anda Salah!</div>';
                        }
                    }
                    else{
                        echo '<div class="alert alert-danger mt-4" role="alert">Akun Tidak Tersedia!</div>';
                    }
                }
                ?>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
