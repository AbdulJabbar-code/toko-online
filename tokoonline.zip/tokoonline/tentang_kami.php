<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Toko Onlin | TENTANG KAMI</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="fontawesome-free-6.4.0-web/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
            <?php require "navbar.php"; ?>
            <div class="container-fluid banner2 d-flex align-items-center">
                <div class="container">
                    <h1 class="text-white text-center">TOKO ONLINEKU</h1>
                </div>
            </div>

            <div class="container-fluid py-5">
                <div class="conntainer fs-5 justify-content-center">
                    <p>Selamat datang di Toko Onlineku! Kami adalah destinasi belanja online terpercaya 
                    yang menyediakan berbagai produk berkualitas untuk memenuhi kebutuhan Anda. Sebagai
                    toko online yang berdedikasi, misi kami adalah memberikan pengalaman belanja yang 
                    nyaman dan memuaskan kepada pelanggan kami.</p>
                    <p>Di Toko Onlineku, kami menawarkan beragam kategori produk yang mencakup fashion,
                    elektronik, peralatan rumah tangga, kecantikan, mainan, dan masih banyak lagi.
                    Kami bekerja sama dengan produsen dan pemasok terkemuka untuk memastikan kualitas
                    produk yang kami tawarkan kepada pelanggan kami.</p>
                    <p>Kenyamanan dan kepuasan pelanggan adalah prioritas utama kami. Dengan antarmuka
                    yang intuitif dan mudah digunakan, Anda dapat dengan mudah menjelajahi berbagai produk
                    yang tersedia di toko kami. Kami juga menyediakan informasi terperinci tentang setiap
                    produk, termasuk deskripsi, spesifikasi, dan ulasan dari pelanggan sebelumnya.</p>
                    <p>Kami mengerti bahwa keamanan transaksi online adalah hal yang penting bagi pelanggan
                    kami. Oleh karena itu, kami menggunakan teknologi enkripsi terkini untuk melindungi 
                    data pribadi Anda dan memastikan transaksi Anda aman dan terjamin.</p>
                    <p>Tim kami terdiri dari tenaga profesional yang siap membantu Anda dengan pertanyaan
                    atau masalah apa pun yang Anda hadapi selama berbelanja di Toko Onlineku. Kami
                    mengutamakan pelayanan pelanggan yang ramah, responsif, dan efisien.</p>
                    <p>Terima kasih telah memilih Toko Onlineku sebagai tujuan belanja online Anda.
                    Kami berharap Anda menikmati pengalaman belanja yang menyenangkan dan mendapatkan
                    produk yang Anda inginkan dengan harga yang terjangkau. Jangan ragu untuk menghubungi 
                    kami jika Anda membutuhkan bantuan atau memiliki pertanyaan lebih lanjut. Selamat 
                    berbelanja di Toko Onlineku!</p>
                </div>
            </div>

            <!-- footer -->
            <?php require "footer.php" ?>

    <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="fontawesome-free-6.4.0-web/js/all.min.js"></script>
</body>
</html>