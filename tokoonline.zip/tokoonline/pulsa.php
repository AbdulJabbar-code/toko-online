<?php
    require "koneksi.php";

    // Query untuk mendapatkan data dari database
    $queryGetData = mysqli_query($con, "SELECT * FROM pembelian_pulsa");

    // Mendapatkan jumlah data
    $countData = mysqli_num_rows($queryGetData);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hasil Pembelian Pulsa</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="fontawesome-free-6.4.0-web/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php require "navbar.php"; ?>

    <div class="container-fluid banner2 d-flex align-items-center">
        <div class="container">
            <h1 class="text-white text-center">TOKO ONLINEKU</h1>
        </div>
    </div>

    <div class="container py-5">
        <h3 class="text-center mb-3">Hasil Pembelian Pulsa</h3>
        <?php if($countData > 0): ?>
            <div class="row">
                <?php while($data = mysqli_fetch_assoc($queryGetData)): ?>
                    <div class="col-md-4 mb-4">
                        <div class="card h-100">
                            <div class="card-body">
                                <h5 class="card-title">Nama Pelanggan: Secret</h5>
                                <p class="card-text">No. Telepon:*********</p>
                                <p class="card-text">Provider:<?php echo $data['provider']; ?></p>
                                <p class="card-text">Nilai Pulsa:Rp.<?php echo $data['nilai_pulsa']; ?>;</p>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        <?php else: ?>
            <p class="text-center">Belum ada hasil pembelian pulsa.</p>
        <?php endif; ?>
    </div>

    <!-- footer -->
    <?php require "footer.php" ?>

    <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="fontawesome-free-6.4.0-web/js/all.min.js"></script>
</body>
</html>
