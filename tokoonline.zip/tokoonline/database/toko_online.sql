-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 08, 2024 at 10:03 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `toko_online`
--

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE `kategori` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`id`, `nama`) VALUES
(1, 'baju pria'),
(2, 'baju wanita'),
(3, 'kacamata'),
(10, 'baju anak-anak'),
(11, 'topi'),
(12, 'sepatu'),
(13, 'jam tangan'),
(14, 'hoodie'),
(15, 'electronic'),
(16, 'celana');

-- --------------------------------------------------------

--
-- Table structure for table `pembelian_pulsa`
--

CREATE TABLE `pembelian_pulsa` (
  `id` int(11) NOT NULL,
  `nama_pelanggan` varchar(255) NOT NULL,
  `nomor_telepon` varchar(15) NOT NULL,
  `provider` varchar(50) NOT NULL,
  `nilai_pulsa` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pembelian_pulsa`
--

INSERT INTO `pembelian_pulsa` (`id`, `nama_pelanggan`, `nomor_telepon`, `provider`, `nilai_pulsa`) VALUES
(1, 'jojo', '83729472396496', 'telkomsell', '50000.00'),
(3, 'jabbar', '4652454345', 'im3', '15000.00'),
(5, 'DSADA', '1232121342', '3', '150000.00'),
(6, 'natan', '9821973986217', 'xl', '100000.00'),
(8, 'tirto', '53765765', 'im3', '50000.00');

-- --------------------------------------------------------

--
-- Table structure for table `produk`
--

CREATE TABLE `produk` (
  `id` int(11) NOT NULL,
  `kategori_id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `harga` double NOT NULL,
  `foto` varchar(255) DEFAULT NULL,
  `detail` text DEFAULT NULL,
  `ketersediaan_stok` enum('habis','tersedia') DEFAULT 'tersedia'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `produk`
--

INSERT INTO `produk` (`id`, `kategori_id`, `nama`, `harga`, `foto`, `detail`, `ketersediaan_stok`) VALUES
(3, 10, 'baju ff anak-anak', 95000, 'AS3e2DEw4LCMZGeUQlQ9.jpg', '                                                                                                                                            Baju Free Fire (FF) anak-anak dirancang khusus untuk menghadirkan pengalaman bermain yang menyenangkan dan stylish. Terbuat dari bahan berkualitas tinggi, baju ini memberikan kenyamanan dan keawetan dalam penggunaan sehari-hari.\r\n\r\nDesain baju FF anak-anak didasarkan pada karakter-karakter ikonik dari permainan Free Fire yang sangat populer. Setiap baju memiliki gambar-gambar yang hidup dan warna-warna yang cerah untuk menarik perhatian anak-anak. Dengan desain yang trendy dan modern, baju ini akan membuat anak Anda merasa keren dan percaya diri.\r\n\r\nSelain itu, baju FF anak-anak juga memiliki fitur-fitur yang mengagumkan. Beberapa model dilengkapi dengan logo Free Fire yang mencolok di bagian depan, sementara yang lain memiliki cetakan gambar karakter favorit yang tampak nyata. Bahan baju ini juga tahan lama dan mudah dijaga, sehingga cocok untuk digunakan saat bermain di luar rumah atau acara sehari-hari.\r\n\r\nKetika anak Anda memakai baju FF, mereka dapat merasakan semangat dan kegembiraan dari permainan Free Fire. Baju ini tidak hanya berfungsi sebagai pakaian, tetapi juga sebagai cara untuk menyatakan kecintaan mereka terhadap permainan yang disukai. Baju FF anak-anak juga dapat menjadi hadiah yang sempurna untuk ulang tahun atau acara khusus lainnya.\r\n\r\nTersedia dalam berbagai ukuran, baju FF anak-anak dapat dengan mudah disesuaikan dengan ukuran tubuh anak Anda. Pastikan untuk memilih ukuran yang tepat agar baju ini pas dan nyaman saat dikenakan. Terlebih lagi, baju FF anak-anak dapat dibeli secara online atau di toko-toko permainan terdekat, sehingga Anda dapat dengan mudah mendapatkannya.\r\n\r\nDengan baju FF anak-anak, anak Anda dapat mengungkapkan kecintaan mereka terhadap permainan Free Fire dengan gaya yang unik dan trendy. Jadikanlah permainan favorit mereka menjadi bagian dari gaya berpakaian sehari-hari. Dapatkanlah baju FF anak-anak sekarang juga dan saksikan kegembiraan yang ditimbulkan oleh permainan ini terpancar melalui penampilan mereka!                                                                                                                ', 'tersedia'),
(4, 11, 'Topi', 87000, '91dJ7SMAGNefL2xZzxtx.jpg', 'Kami menjual topi abu-abu yang stylish dan berkualitas tinggi. Topi ini terbuat dari bahan berkualitas, seperti wol atau katun, untuk memberikan kenyamanan saat dipakai. Desainnya yang simpel namun menarik membuatnya cocok untuk dipadukan dengan berbagai gaya pakaian.\r\n\r\nTopi abu-abu ini tersedia dalam berbagai ukuran, mulai dari ukuran anak-anak hingga ukuran dewasa, sehingga dapat dipakai oleh semua kalangan. Kami juga menyediakan beragam gaya topi abu-abu, mulai dari topi fedora yang klasik hingga topi beanie yang lebih santai.\r\n\r\nHarga topi abu-abu kami bervariasi tergantung pada bahan, desain, dan merek. Namun, kami berusaha untuk menawarkan harga yang kompetitif dan terjangkau bagi pelanggan kami. Anda dapat membeli topi ini secara online melalui situs web kami atau mengunjungi toko fisik kami di lokasi yang telah ditentukan.\r\n\r\nJika Anda mencari topi abu-abu yang modis dan berkualitas tinggi, jangan ragu untuk memilih produk kami. Dapatkan penampilan yang keren dan tambahkan sentuhan gaya dengan topi abu-abu kami yang terbaik!', 'tersedia'),
(5, 12, 'sepatu 1', 230000, '2x3uhSkOVTcODHZWU5ft.jpg', 'Kami memiliki sepatu sneakers dengan warna cream yang stylish dan nyaman untuk digunakan sehari-hari. Sepatu sneakers cream kami menawarkan kombinasi desain yang trendi dan warna yang netral, sehingga cocok dipadukan dengan berbagai gaya pakaian.\r\n\r\nSepatu sneakers cream ini terbuat dari bahan berkualitas tinggi, seperti kulit sintetis atau kanvas, yang memberikan kenyamanan dan daya tahan yang baik. Sol yang fleksibel dan empuk memberikan langkah yang nyaman, sementara desain yang ringan memungkinkan Anda beraktivitas tanpa merasa terbebani.\r\n\r\nKami menyediakan berbagai model sepatu sneakers cream, termasuk sepatu dengan tali atau tanpa tali, serta berbagai aksen desain seperti pola, logo, atau detail berwarna lainnya. Ukuran sepatu juga tersedia mulai dari ukuran anak-anak hingga ukuran dewasa, sehingga dapat memenuhi kebutuhan semua kalangan.\r\n\r\nHarga sepatu sneakers cream kami bervariasi tergantung pada merek, desain, dan material yang digunakan. Kami berusaha untuk memberikan harga yang kompetitif dan memberikan nilai terbaik bagi pelanggan kami.\r\n\r\nAnda dapat membeli sepatu sneakers cream ini melalui situs web kami atau mengunjungi toko fisik kami untuk melihat koleksi lengkapnya. Temukan sepatu sneakers cream yang cocok dengan gaya Anda dan tambahkan sentuhan kasual yang trendi pada penampilan Anda sehari-hari.', 'tersedia'),
(6, 1, 'kemeja', 120000, 'jmRoyCS2RusYM9CGYKq9.jpg', 'Kami menawarkan kemeja pria dengan warna navy yang elegan dan cocok untuk berbagai kesempatan. Kemeja pria warna navy ini memberikan tampilan klasik dan serbaguna yang dapat dipadukan dengan berbagai gaya pakaian.\r\n\r\nKemeja warna navy kami terbuat dari bahan berkualitas tinggi, seperti katun atau linen, untuk memberikan kenyamanan dan tahan lama saat digunakan. Desainnya yang rapi dengan kerah klasik dan kancing depan menjadikannya pilihan yang sempurna untuk acara formal atau santai.\r\n\r\nKami menyediakan kemeja warna navy dalam berbagai ukuran, mulai dari ukuran kecil hingga ukuran besar, untuk memastikan setiap pria dapat menemukan ukuran yang sesuai dengan tubuh mereka. Selain itu, kami juga memiliki berbagai gaya kemeja, mulai dari kemeja slim fit yang lebih modern hingga kemeja regular fit yang lebih longgar.\r\n\r\nHarga kemeja warna navy kami bervariasi tergantung pada merek, bahan, dan desain yang dipilih. Kami berusaha untuk memberikan harga yang kompetitif dan memberikan nilai terbaik bagi pelanggan kami.\r\n\r\nAnda dapat membeli kemeja warna navy ini melalui situs web kami atau mengunjungi toko fisik kami untuk melihat koleksi lengkapnya. Pilih kemeja warna navy yang sesuai dengan gaya dan kebutuhan Anda, dan tambahkan sentuhan elegan pada penampilan Anda dengan kemeja pria warna navy kami yang berkualitas tinggi.    ', 'tersedia'),
(7, 1, 'kemeja 2', 150000, 'nYIyVDSJHU72TbvBAUwg.jpg', 'Kami menyediakan kemeja pria dengan motif batik yang indah dan khas. Kemeja batik pria kami adalah pilihan yang sempurna untuk menciptakan penampilan yang klasik, elegan, dan memperlihatkan kekayaan budaya Indonesia.\r\n\r\nKemeja batik pria kami tersedia dalam berbagai motif dan warna tradisional batik, seperti parang, lereng, atau megamendung, serta kombinasi warna yang menarik. Setiap kemeja batik kami ditenun dengan hati-hati menggunakan teknik tradisional, sehingga menciptakan karya seni yang unik dan istimewa.\r\n\r\nKami menawarkan berbagai model kemeja batik, mulai dari kemeja dengan kerah standar hingga kemeja dengan kerah mandarin yang lebih formal. Bahan yang digunakan juga berkualitas tinggi, seperti katun atau sutra, untuk memberikan kenyamanan saat dipakai.\r\n\r\nHarga kemeja batik pria kami bervariasi tergantung pada motif, bahan, dan tingkat kerumitan pembuatannya. Kami berusaha untuk memberikan harga yang sebanding dengan kualitas dan keindahan kemeja batik kami.\r\n\r\nAnda dapat membeli kemeja batik pria ini melalui situs web kami atau mengunjungi toko fisik kami yang khusus menjual produk-produk batik. Jadikan kemeja batik sebagai pilihan Anda untuk tampil elegan dan memperlihatkan apresiasi terhadap warisan budaya Indonesia.', 'tersedia'),
(8, 1, 'baju double layer', 100000, 'Ln1CuLvMXlzVpV8dlEJK.jpg', 'Kami menyediakan baju pria dengan desain double layer yang menarik dan modern. Baju pria double layer memiliki lapisan ganda yang memberikan tampilan yang unik dan menarik. \r\n\r\nDesain double layer pada baju pria dapat berupa lapisan dalam yang terlihat sedikit melampaui lapisan luar, memberikan sentuhan kontras dan dimensi pada penampilan Anda. Ada juga beberapa model baju double layer yang memiliki bagian depan yang terbuka, sehingga lapisan dalam dapat terlihat dengan jelas.\r\n\r\nBahan yang digunakan untuk baju pria double layer biasanya terbuat dari campuran katun atau linen, yang memberikan kenyamanan dan sirkulasi udara yang baik. Anda dapat memilih baju double layer dengan berbagai gaya, seperti kaos double layer dengan t-shirt atau kemeja double layer dengan motif yang menarik.\r\n\r\nHarga baju pria double layer kami bervariasi tergantung pada merek, bahan, dan desain yang dipilih. Kami berusaha untuk memberikan harga yang kompetitif dan kualitas yang baik bagi pelanggan kami.\r\n\r\nAnda dapat membeli baju pria double layer ini melalui situs web kami atau mengunjungi toko fisik kami untuk melihat koleksi lengkapnya. Pilih baju double layer yang sesuai dengan gaya dan selera Anda, dan tambahkan sentuhan modern pada penampilan Anda dengan baju pria double layer kami yang stylish.', 'tersedia'),
(9, 3, 'kacamata 1', 150000, 'FRiGgPksDTZa5vg4zQVn.jpg', 'Kami menyediakan berbagai macam kacamata hitam untuk pria dengan berbagai desain dan gaya yang trendi. Kacamata hitam merupakan aksesori yang tidak hanya memberikan perlindungan dari sinar matahari, tetapi juga menjadi bagian penting dari penampilan yang keren dan stylish.\r\n\r\nKacamata hitam kami tersedia dalam berbagai bentuk seperti aviator, wayfarer, cat-eye, dan lainnya, sehingga Anda dapat memilih sesuai dengan preferensi dan bentuk wajah Anda. Kami juga menawarkan berbagai pilihan warna lensa dan bingkai, termasuk hitam, cokelat, biru, atau bahkan bingkai warna-warni yang mencolok.\r\n\r\nKacamata hitam kami menggunakan lensa yang memberikan perlindungan UV 400, sehingga melindungi mata Anda dari sinar UV berbahaya. Selain itu, bingkai yang terbuat dari material berkualitas tinggi seperti plastik atau logam, memberikan daya tahan dan kenyamanan saat digunakan.\r\n\r\nHarga kacamata hitam kami bervariasi tergantung pada merek, desain, dan material yang digunakan. Kami berusaha untuk memberikan harga yang kompetitif dan memastikan pelanggan kami mendapatkan kacamata hitam berkualitas.\r\n\r\nAnda dapat membeli kacamata hitam ini melalui situs web kami atau mengunjungi toko fisik kami untuk melihat koleksi lengkapnya. Pilih kacamata hitam yang sesuai dengan gaya dan kebutuhan Anda, dan tambahkan sentuhan gaya pada penampilan Anda dengan kacamata hitam kami yang modis dan fungsional.', 'tersedia'),
(10, 2, 'gamis wanita', 220000, 'VS7mKJEkMe0bXMBCggOR.jpg', 'Kami menyediakan berbagai pilihan gamis Islami untuk wanita yang mengutamakan penampilan yang sopan dan sesuai dengan prinsip-prinsip busana Islami. Gamis Islami adalah jenis pakaian wanita yang meliputi baju panjang yang longgar dengan lengan panjang dan rok yang panjang pula.\r\n\r\nGamis Islami kami dirancang dengan memperhatikan desain yang elegan dan sesuai dengan tren fashion terkini. Kami menawarkan berbagai model dan gaya gamis, termasuk gamis dengan kerah, gamis dengan detail bordir atau aplikasi, gamis dengan aksen lipit, dan masih banyak lagi. Anda juga dapat memilih gamis dengan berbagai pilihan warna dan motif yang beragam.\r\n\r\nKami menggunakan bahan yang berkualitas, seperti katun, satin, atau sifon, untuk memberikan kenyamanan dan pergerakan yang leluasa saat mengenakan gamis Islami. Kami juga memperhatikan detail dan kualitas jahitan untuk memastikan produk kami tahan lama dan nyaman dipakai.\r\n\r\nHarga gamis Islami wanita kami bervariasi tergantung pada merek, bahan, dan desain yang dipilih. Kami berusaha untuk memberikan harga yang kompetitif dan memberikan nilai terbaik bagi pelanggan kami.\r\n\r\nAnda dapat membeli gamis Islami wanita ini melalui situs web kami atau mengunjungi toko fisik kami yang khusus menjual pakaian Islami. Pilih gamis Islami yang sesuai dengan gaya dan preferensi Anda, dan tambahkan sentuhan kecantikan dan kesopanan dalam penampilan Anda dengan gamis Islami wanita dari koleksi kami.', 'tersedia'),
(11, 12, 'sepatu kets', 300000, 'TuY9ifWPzyoQLx5iL4Fi.jpg', 'Kami menyediakan berbagai macam sepatu kets yang nyaman dan stylish untuk pria, wanita, dan anak-anak. Sepatu kets, juga dikenal sebagai sepatu sneakers atau sepatu olahraga, adalah jenis sepatu yang dirancang untuk memberikan kenyamanan dan daya tahan saat digunakan sehari-hari atau untuk aktivitas fisik ringan.\r\n\r\nSepatu kets kami tersedia dalam berbagai model, gaya, dan warna yang trendi. Kami menawarkan sepatu kets dengan tali, sepatu kets slip-on tanpa tali, atau bahkan sepatu kets dengan desain unik seperti platform atau chunky sole. Anda dapat memilih sepatu kets dengan material seperti kanvas, kulit sintetis, atau kombinasi material yang memberikan fleksibilitas dan keawetan.\r\n\r\nKami juga memiliki berbagai ukuran sepatu kets untuk memenuhi kebutuhan semua kalangan, dari anak-anak hingga dewasa. Sebagian besar sepatu kets kami dilengkapi dengan sol yang nyaman dan fleksibel, memberikan peredaman yang baik saat berjalan atau berlari.\r\n\r\nHarga sepatu kets kami bervariasi tergantung pada merek, model, dan bahan yang digunakan. Kami berusaha untuk memberikan harga yang kompetitif dan memberikan nilai terbaik bagi pelanggan kami.\r\n\r\nAnda dapat membeli sepatu kets ini melalui situs web kami atau mengunjungi toko fisik kami untuk melihat koleksi lengkapnya. Pilih sepatu kets yang sesuai dengan gaya dan kebutuhan Anda, dan tambahkan sentuhan kasual dan sporty pada penampilan Anda dengan sepatu kets kami yang nyaman dan modis.', 'tersedia'),
(12, 12, 'sepatu converse', 700000, 'DBVpXPetuWX5nqA5yzb8.jpg', 'Kami menyediakan sepatu Converse, merek sepatu yang terkenal dengan desain klasik dan ikonik. Sepatu Converse adalah sepatu kets yang memiliki ciri khas dengan sol karet yang tebal dan bingkai berwarna putih, serta memiliki desain low-top atau high-top yang khas.\r\n\r\nSepatu Converse kami tersedia dalam berbagai model dan warna yang menarik. Anda dapat memilih sepatu Converse dengan desain low-top yang lebih ramping atau high-top yang memberikan penutup lebih tinggi pada pergelangan kaki. Kami juga menyediakan berbagai pilihan warna seperti putih, hitam, merah, biru, dan masih banyak lagi.\r\n\r\nBahan yang digunakan untuk sepatu Converse umumnya adalah kanvas yang nyaman dan fleksibel, sehingga memberikan kenyamanan saat dipakai. Sol karet yang tebal memberikan perlindungan dan daya tahan yang baik.\r\n\r\nHarga sepatu Converse bervariasi tergantung pada model, ukuran, dan edisi khusus yang mungkin ada. Harga untuk sepatu Converse juga dapat dipengaruhi oleh faktor musiman atau kolaborasi dengan merek atau artis terkenal.\r\n\r\nAnda dapat membeli sepatu Converse ini melalui situs web kami atau mengunjungi toko fisik kami yang menjual produk Converse resmi. Pilih sepatu Converse yang sesuai dengan gaya dan kebutuhan Anda, dan tambahkan sentuhan klasik dan ikonik pada penampilan Anda dengan sepatu Converse kami yang terkenal dan populer.', 'tersedia'),
(13, 2, 'baju wanita bercorak', 160000, 'oep4mL97KOvtvAwx7DDg.jpg', 'Kami menyediakan berbagai pilihan kemeja wanita batik yang indah dan khas. Kemeja wanita batik merupakan pilihan yang tepat untuk menciptakan penampilan yang elegan, sopan, dan memperlihatkan kekayaan budaya Indonesia.\r\n\r\nKemeja wanita batik kami dirancang dengan perpaduan antara keindahan motif batik tradisional dan gaya modern yang sesuai dengan tren fashion terkini. Kami menawarkan berbagai model dan potongan kemeja, termasuk kemeja dengan kerah standar, kemeja dengan kerah mandarin, kemeja lengan panjang, dan kemeja lengan pendek.\r\n\r\nKami memiliki beragam pilihan motif batik, seperti parang, lereng, kawung, atau motif khas daerah tertentu. Setiap kemeja batik wanita kami dibuat dengan hati-hati menggunakan teknik tradisional, sehingga menciptakan karya seni yang unik dan istimewa.\r\n\r\nKami menggunakan bahan-bahan berkualitas tinggi, seperti katun, sutra, atau rayon, untuk memberikan kenyamanan dan tampilan yang baik saat dipakai. Kualitas jahitan dan detail juga menjadi perhatian kami untuk memastikan produk kami tahan lama dan sesuai dengan harapan pelanggan.\r\n\r\nHarga kemeja wanita batik kami bervariasi tergantung pada merek, motif, bahan, dan tingkat kerumitan pembuatannya. Kami berusaha untuk memberikan harga yang sebanding dengan kualitas dan keindahan kemeja batik kami.\r\n\r\nAnda dapat membeli kemeja wanita batik ini melalui situs web kami atau mengunjungi toko fisik kami yang khusus menjual produk-produk batik. Jadikan kemeja batik sebagai pilihan Anda untuk tampil elegan dan memperlihatkan apresiasi terhadap warisan budaya Indonesia dalam penampilan Anda.', 'tersedia'),
(14, 2, 'baju kemeja wanita', 120000, 'M8HRqdSSm7fLdtsD7K3T.jpg', 'Kami menyediakan berbagai pilihan baju kemeja wanita dengan warna putih yang klasik dan serbaguna. Baju kemeja wanita warna putih adalah pilihan yang elegan dan dapat dipadukan dengan berbagai gaya pakaian.\r\n\r\nBaju kemeja wanita warna putih kami memiliki desain yang bervariasi, mulai dari kemeja dengan kerah standar hingga kemeja dengan kerah mandarin atau kemeja lengan panjang hingga lengan pendek. Kami juga menyediakan berbagai model, seperti kemeja dengan potongan regular fit, slim fit, atau loose fit, agar Anda dapat menemukan yang sesuai dengan preferensi dan bentuk tubuh Anda.\r\n\r\nBahan yang digunakan untuk baju kemeja wanita kami adalah bahan berkualitas tinggi seperti katun, linen, atau sifon, untuk memberikan kenyamanan dan penampilan yang baik. Kami memperhatikan detail dan kualitas jahitan untuk memastikan produk kami tahan lama dan nyaman dipakai.\r\n\r\nHarga baju kemeja wanita warna putih kami bervariasi tergantung pada merek, bahan, dan desain yang dipilih. Kami berusaha untuk memberikan harga yang kompetitif dan memberikan nilai terbaik bagi pelanggan kami.\r\n\r\nAnda dapat membeli baju kemeja wanita warna putih ini melalui situs web kami atau mengunjungi toko fisik kami untuk melihat koleksi lengkapnya. Pilih baju kemeja wanita warna putih yang sesuai dengan gaya dan kebutuhan Anda, dan tambahkan sentuhan elegan pada penampilan Anda dengan baju kemeja wanita warna putih kami yang berkualitas tinggi.', 'tersedia'),
(15, 10, 'gamis anak anak', 90000, 'DzYRs7YxGvu9EnAHGpd9.jpg', '                    Kami menyediakan berbagai pilihan baju gamis anak perempuan yang cantik dan nyaman untuk dipakai. Baju gamis anak perempuan adalah pakaian yang cocok untuk menciptakan penampilan yang sopan dan sesuai dengan prinsip-prinsip busana Islami.\r\n\r\nBaju gamis anak perempuan kami dirancang dengan memperhatikan desain yang menarik dan sesuai dengan selera anak-anak. Kami menawarkan berbagai model dan potongan baju gamis, mulai dari model dengan kerah atau tanpa kerah, lengan panjang atau pendek, dan rok panjang hingga rok midi.\r\n\r\nKami juga menyediakan berbagai pilihan warna dan motif yang ceria, seperti pola bunga, motif geometris, atau aksen bordir yang menambahkan sentuhan feminin pada baju gamis anak perempuan kami. Bahan yang digunakan biasanya adalah katun atau rayon yang lembut dan nyaman di kulit anak-anak.\r\n\r\nHarga baju gamis anak perempuan kami bervariasi tergantung pada merek, desain, dan kualitas bahan yang digunakan. Kami berusaha untuk memberikan harga yang kompetitif dan memberikan kualitas yang baik bagi pelanggan kami.\r\n\r\nAnda dapat membeli baju gamis anak perempuan ini melalui situs web kami atau mengunjungi toko fisik kami yang khusus menjual pakaian anak-anak. Pilih baju gamis anak perempuan yang sesuai dengan selera dan kebutuhan anak Anda, dan tambahkan sentuhan kecantikan dan kesopanan dalam penampilan mereka dengan baju gamis anak perempuan dari koleksi kami.                ', 'tersedia'),
(17, 14, 'hodie hitam', 99000, 'RuwJFoyl1VLXgWHemPb9.jpg', 'Kami menyediakan hoodie hitam yang stylish dan nyaman untuk pria, wanita, dan anak-anak. Hoodie hitam adalah pakaian lengan panjang dengan hood (tudung) di bagian belakangnya yang dapat memberikan tampilan yang kasual namun tetap trendy.\r\n\r\nHoodie hitam kami tersedia dalam berbagai model dan desain yang menarik. Kami menawarkan hoodie dengan resleting depan atau hoodie tanpa resleting, dengan atau tanpa kantong di bagian depannya. Anda juga dapat memilih hoodie dengan berbagai aksen seperti logo, pola, atau tulisan yang memberikan gaya yang unik.\r\n\r\nKami menggunakan bahan berkualitas tinggi seperti katun atau campuran katun-poliester untuk memberikan kenyamanan saat dipakai dan tahan lama. Hoodie hitam kami juga dilengkapi dengan hoodie yang dapat disesuaikan dan resleting yang berkualitas.\r\n\r\nHarga hoodie hitam kami bervariasi tergantung pada merek, desain, dan bahan yang digunakan. Kami berusaha untuk memberikan harga yang kompetitif dan memberikan nilai terbaik bagi pelanggan kami.\r\n\r\nAnda dapat membeli hoodie hitam ini melalui situs web kami atau mengunjungi toko fisik kami untuk melihat koleksi lengkapnya. Pilih hoodie hitam yang sesuai dengan gaya dan kebutuhan Anda, dan tambahkan sentuhan kasual dan modis pada penampilan Anda dengan hoodie hitam kami yang nyaman dan stylish.', 'tersedia');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(1, 'admin', 'rahasia');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pembelian_pulsa`
--
ALTER TABLE `pembelian_pulsa`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`id`),
  ADD KEY `nama` (`nama`),
  ADD KEY `kategori_produk` (`kategori_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `kategori`
--
ALTER TABLE `kategori`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `pembelian_pulsa`
--
ALTER TABLE `pembelian_pulsa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `produk`
--
ALTER TABLE `produk`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `produk`
--
ALTER TABLE `produk`
  ADD CONSTRAINT `kategori_produk` FOREIGN KEY (`kategori_id`) REFERENCES `kategori` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
